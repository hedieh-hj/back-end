﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace code.Models.EntityModels
{
    public class UserMetaData
    {
        
            public int Id { get; set; }


        //[Display(Name="نام")] FARSI KARDN FIELD HAYI KE MIKHAHIM 
        [Required(ErrorMessage = "this field could not be empty", AllowEmptyStrings = false)]
        public string Name { get; set; }


        [Required(ErrorMessage = "this field could not be empty", AllowEmptyStrings = false)]
        public string Family { get; set; }



        [Required(ErrorMessage = "this field could not be empty", AllowEmptyStrings = false)]
        [StringLength(11,MinimumLength =11 , ErrorMessage = "11 character")]
        public string Mobile { get; set; }




        public string Telephone { get; set; }


        [StringLength(10, MinimumLength = 10, ErrorMessage = "11 character")]
        [Required(ErrorMessage = "this field could not be empty", AllowEmptyStrings = false)]
        public string Nationalcode { get; set; }

        public string Gmail { get; set; }


    }
}
//etesal be ham 
namespace code.Models.Tabels
{
    [ModelMetadataType(typeof(EntityModels.UserMetaData))]
    public partial class User
    {

    }
}
