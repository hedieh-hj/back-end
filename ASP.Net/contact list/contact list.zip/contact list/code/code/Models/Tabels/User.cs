﻿using System;
using System.Collections.Generic;

#nullable disable

namespace code.Models.Tabels
{
    public partial class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Family { get; set; }
        public string Mobile { get; set; }
        public string Telephone { get; set; }
        public string Nationalcode { get; set; }
        public string Gmail { get; set; }
    }
}

